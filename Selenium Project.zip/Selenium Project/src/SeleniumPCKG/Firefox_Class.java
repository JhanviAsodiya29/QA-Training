package SeleniumPCKG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Firefox_Class {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver;
		
		System.setProperty("webdriver.gecko.driver","D:\\geckodriver.exe");
		
		driver= new FirefoxDriver();
		
		driver.manage().window().maximize();
		
		driver.get("http://google.com");
		
	}

}