package SeleniumPCKG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_Logout {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver;
		
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("http://automationpractice.com/index.php");
		
		driver.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")).click();
		Thread.sleep(2000);
		
		WebElement element =driver.findElement(By.id("email"));
		element.sendKeys("jhanviasodiya+a777778@gmail.com");
		Thread.sleep(2000);
		
		WebElement element1 =driver.findElement(By.id("passwd"));
		element1.sendKeys("jhanvi@123");
		Thread.sleep(2000);
		
		driver.findElement(By.id("SubmitLogin")).click();
		
	}

}
